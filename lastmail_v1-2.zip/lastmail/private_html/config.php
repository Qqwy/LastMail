<?php

//Database Settings
$SQL_HOSTNAME = 'localhost';
$SQL_USER = 'johndoe';
$SQL_PASSWORD  = 'supersecret';
$SQL_DATABASE = 'test';
$SQL_SALT = 'protect-this-with-your-life';


//Domain settings
$ROOT_URL = "https://last-mail.org";


?>