﻿<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Refresh" content="0;URL=https://last-mail.org" /> 
	</head>
	<body>
		
	</body>
</html>