﻿<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Refresh" content="0;URL=https://last-mail.org" />
	</head>
	<body>
		<p>Redirecting to the secure HTTPS version of the site.</p>
		
		If this is not working properly, please go there manually: <a href="https://last-mail.org" >https://last-mail.org</a>
		
	</body>
</html>