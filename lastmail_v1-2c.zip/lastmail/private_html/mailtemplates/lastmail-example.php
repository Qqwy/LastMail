﻿<?php
include "lastmail-header.html";
?>

<p>This is a triumph.</p>

<p>I'm making a note here, Huge Success</p>

<?php
include "lastmail-footer.html";
?>